﻿namespace Print
{
    using System;

    internal class Class1
    {
    }
}

