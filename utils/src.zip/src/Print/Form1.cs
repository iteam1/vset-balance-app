﻿namespace Print
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Drawing.Printing;
    using System.Net;
    using System.Net.Sockets;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;

    public class Form1 : Form
    {
        private Thread startPrintService;
        private bool closeForm;
        private Socket socket;
        private static string printerName = "ZDesigner GC420t (EPL)";
        public static string data = null;
        private IContainer components;
        private Button button1;
        private TextBox textBox1;
        private TextBox textBox2;

        public Form1()
        {
            this.InitializeComponent();
            this.textBox2.Text = Dns.Resolve(Dns.GetHostName()).AddressList[0].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.button1.Enabled = false;
            this.startPrintService = new Thread(new ThreadStart(this.RunServiceThread));
            this.startPrintService.Start();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                this.closeForm = true;
                this.socket.Close();
                this.startPrintService.Abort();
                this.startPrintService = null;
            }
            catch (Exception)
            {
            }
        }

        private void InitializeComponent()
        {
            this.button1 = new Button();
            this.textBox1 = new TextBox();
            this.textBox2 = new TextBox();
            base.SuspendLayout();
            this.button1.Location = new Point(0x37, 0x88);
            this.button1.Name = "button1";
            this.button1.Size = new Size(0x7d, 0x17);
            this.button1.TabIndex = 0;
            this.button1.Text = "Start Print Service";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new EventHandler(this.button1_Click);
            this.textBox1.Location = new Point(0x37, 0x48);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Size(0x7d, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "ZDesigner GC420t (EPL)";
            this.textBox2.Location = new Point(0x37, 0x69);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Size(0x7d, 20);
            this.textBox2.TabIndex = 2;
            base.AutoScaleDimensions = new SizeF(6f, 13f);
            base.AutoScaleMode = AutoScaleMode.Font;
            base.ClientSize = new Size(0x11c, 0x105);
            base.Controls.Add(this.textBox2);
            base.Controls.Add(this.textBox1);
            base.Controls.Add(this.button1);
            base.Name = "Form1";
            this.Text = "Form1";
            base.FormClosed += new FormClosedEventHandler(this.Form1_FormClosed);
            base.ResumeLayout(false);
            base.PerformLayout();
        }

        private void RunServiceThread()
        {
            string szString = "^XA^FO40,80^BY2^BCN,80,Y,N,N^FD>;2000303002^FS^FX^CF0,,20^FWN^FO10,10^FDTranThiLanHoa^FS^FWN^FO10,30^FDDOB:07-10-1986Sex:F^FS^FWN^FO10,50^FDCompanyName^FS^FWN^FO50,190^FDWholeBlood^FS^FWR^FO230,80^FD31/05/2017^FS^FWR^FO250,80^FD20003030^FS^PQ2^XZ";
            this.StartListening();
            if (this.textBox1.Text.Length != 0)
            {
                RawPrinterHelper.SendStringToPrinter(this.textBox1.Text, szString);
            }
            else
            {
                PrintDialog dialog = new PrintDialog {
                    PrinterSettings = new PrinterSettings()
                };
                if (DialogResult.OK == dialog.ShowDialog(this))
                {
                    RawPrinterHelper.SendStringToPrinter(dialog.PrinterSettings.PrinterName, szString);
                    this.textBox1.Text = dialog.PrinterSettings.PrinterName;
                }
            }
        }

        public void StartListening()
        {
            byte[] buffer = new byte[0x400];
            IPAddress address = Dns.Resolve(Dns.GetHostName()).AddressList[0];
            IPEndPoint localEP = new IPEndPoint(address, 0x2af8);
            this.textBox2.Text = address.ToString();
            this.socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                this.socket.Bind(localEP);
                this.socket.Listen(10);
                while (true)
                {
                    Socket socket = this.socket.Accept();
                    data = null;
                    while (true)
                    {
                        buffer = new byte[0x400];
                        int count = socket.Receive(buffer);
                        data = data + Encoding.ASCII.GetString(buffer, 0, count);
                        bool flag = data.IndexOf("<EOF>") > -1;
                        if (this.closeForm || flag)
                        {
                            data = data.Replace("<EOF>", "");
                            RawPrinterHelper.SendStringToPrinter(this.textBox1.Text, data);
                            socket.Send(Encoding.ASCII.GetBytes(data));
                            socket.Shutdown(SocketShutdown.Both);
                            socket.Close();
                            if (!this.closeForm)
                            {
                                break;
                            }
                            this.socket.Close(10);
                            return;
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }
    }
}

